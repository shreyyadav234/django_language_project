from django.db import models
from ckeditor.fields import RichTextField
from googletrans import Translator
from django.core.cache import cache
from celery import shared_task



class FAQ(models.Model):
    technique_name = models.CharField(max_length=255, blank=True, null=True)  # NEW FIELD
    question = models.TextField()
    answer = RichTextField()
    question_hi = models.TextField(blank=True, null=True)
    question_bn = models.TextField(blank=True, null=True)

    def translate_fields(self):
        """
        Automatically translate the FAQ's question fields asynchronously using Celery.
        """
        translate_faq.delay(self.id)  # Calling the Celery task asynchronously

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)  # Save the object first
        self.translate_fields()  # Then trigger translation in the background
        cache.set(f'faq_{self.id}', self, timeout=3600)  # Store FAQ in cache for 1 hour

    def get_translated_question(self, lang='en'):
        """
        Retrieve the translated question based on the selected language.
        """
        translation_field = f"question_{lang}"
        return getattr(self, translation_field, self.question)

    def _str_(self):
        return self.question

# Celery task to perform translation asynchronously
@shared_task
def translate_faq(faq_id):
    faq = FAQ.objects.get(id=faq_id)
    translator = Translator()
    if not faq.question_hi:
        faq.question_hi = translator.translate(faq.question, src='en', dest='hi').text
    if not faq.question_bn:
        faq.question_bn = translator.translate(faq.question, src='en', dest='bn').text
    faq.save()