from django.db import models
from ckeditor.fields import RichTextField
from django.core.cache import cache
from celery import shared_task
from googletrans import Translator


class FAQ(models.Model):
    technique_name = models.CharField(max_length=255, blank=True, null=True)  # NEW FIELD
    question = models.TextField()
    answer = RichTextField()
    question_hi = models.TextField(blank=True, null=True)
    question_bn = models.TextField(blank=True, null=True)

    def translate_fields(self):
        """ Automatically translate the FAQ's question fields asynchronously using Celery. """
        translate_faq.delay(self.id)  # Call Celery task asynchronously

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)  # Save first
        self.translate_fields()  # Trigger translation in the background
        cache.set(f'faq_{self.id}', self, timeout=3600)  # Cache FAQ for 1 hour

    def get_translated_question(self, lang='en'):
        """ Retrieve the translated question based on the selected language. """
        translation_field = f"question_{lang}"
        return getattr(self, translation_field, self.question)

    def __str__(self):
        return self.question


class TranslatedFAQ(models.Model):
    """ Stores translated versions of FAQ questions. """
    faq = models.ForeignKey(FAQ, on_delete=models.CASCADE, related_name="translations")
    language = models.CharField(max_length=10)  # Example: 'hi', 'bn'
    translated_question = models.TextField()

    def __str__(self):
        return f"{self.faq.question} ({self.language})"


# Celery task to translate FAQ asynchronously
@shared_task
def translate_faq(faq_id):
    try:
        faq = FAQ.objects.get(id=faq_id)
        translator = Translator()

        if not faq.question_hi:
            faq.question_hi = translator.translate(faq.question, src='en', dest='hi').text
        if not faq.question_bn:
            faq.question_bn = translator.translate(faq.question, src='en', dest='bn').text

        faq.save()

        # Store translations in TranslatedFAQ model
        for lang, translated_text in [('hi', faq.question_hi), ('bn', faq.question_bn)]:
            TranslatedFAQ.objects.update_or_create(
                faq=faq,
                language=lang,
                defaults={'translated_question': translated_text}
            )

    except FAQ.DoesNotExist:
        print(f"FAQ with ID {faq_id} does not exist.")
