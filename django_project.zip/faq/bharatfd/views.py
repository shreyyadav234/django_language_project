import logging
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from django.core.cache import cache
from googletrans import Translator
from .models import FAQ, TranslatedFAQ
from .serializers import FAQSerializer
from django.db import transaction

logger = logging.getLogger(__name__)

SUPPORTED_LANGUAGES = [
    'sq', 'ro', 'hr', 'ne', 'fa', 'hi', 'cs', 'gu', 'xh', 'ky', 'mi', 'th', 'mr', 'te', 'lo', 'sm', 
    'is', 'mn', 'sn', 'el', 'sk', 'pt', 'sr', 'haw', 'ml', 'ru', 'hi', 'sv', 'zu', 'ar', 'fy', 'ht', 
    'ko', 'he', 'si', 'vi', 'ja', 'bn', 'hy', 'ms', 'pl', 'tr', 'my', 'lv', 'bg', 'nl', 'az', 'fr', 
    'tl', 'en', 'la', 'hu', 'ur', 'id', 'et', 'kn', 'pa', 'ta', 'yi', 'lt', 'es', 'sw', 'it', 'be', 
    'mk', 'bs', 'or', 'ps', 'so', 'km', 'ka', 'af', 'de', 'eu', 'cy', 'am', 'uk', 'da', 'sd'
]

class FAQViewSet(viewsets.ModelViewSet):
    queryset = FAQ.objects.all()
    serializer_class = FAQSerializer

    @action(detail=False, methods=['post'])
    def add_faqs(self, request):
        faqs_data = request.data  # Get the FAQ data from the request body
        
        # Check if data is provided in the correct format
        if not isinstance(faqs_data, list):
            return Response({"error": "FAQ data should be a list of dictionaries."}, status=400)

        # Using transaction to ensure atomicity
        with transaction.atomic():
            faq_objects = []
            for faq_data in faqs_data:
                faq_objects.append(FAQ(
                    question=faq_data['question'],
                    answer=faq_data['answer'],
                    technique_name=faq_data['technique_name']
                ))

            FAQ.objects.bulk_create(faq_objects)  # Bulk create for efficiency

        return Response({"message": "FAQs added successfully"}, status=201)

    @action(detail=False, methods=['get'])
    def language_specific(self, request):
        lang = request.GET.get('lang', 'en')  # Default to 'en' if no language is specified

        # Check if the requested language is supported
        if lang not in SUPPORTED_LANGUAGES:
            return Response({'error': 'Language not supported'}, status=400)

        cache_key = f'faqs_lang_{lang}'

        # Check if response is in cache
        cached_data = cache.get(cache_key)
        if cached_data:
            return Response(cached_data)

        faqs = FAQ.objects.all()
        data = []

        # Initialize the Google Translator
        translator = Translator()

        for faq in faqs:
            # Check if translated FAQ already exists in the database
            translated_faq = TranslatedFAQ.objects.filter(faq=faq, language=lang).first()

            if translated_faq:
                # Use the translation from the database if available
                translated_question = translated_faq.translated_question
                translated_answer = translated_faq.translated_answer
            else:
                # Otherwise, use Google Translate
                try:
                    logger.debug(f"Translating FAQ ID {faq.id}: {faq.question} -> {faq.answer}")

                    # Translate question and answer
                    translated_question = translator.translate(faq.question, dest=lang).text
                    translated_answer = translator.translate(faq.answer, dest=lang).text

                    # Log the translation results
                    logger.debug(f"Translated FAQ ID {faq.id}: Question - {translated_question}, Answer - {translated_answer}")

                    # Save the translated FAQ to the database for future use
                    TranslatedFAQ.objects.create(
                        faq=faq,
                        language=lang,
                        translated_question=translated_question,
                        translated_answer=translated_answer
                    )
                except Exception as e:
                    logger.error(f"Translation failed for FAQ ID {faq.id}: {str(e)}")
                    continue  # Skip this FAQ and continue with the next one

            data.append({
                'technique_name': faq.technique_name,
                'question': translated_question,
                'answer': translated_answer
            })

        # Store response in cache for future requests
        cache.set(cache_key, data, timeout=30)  # Cache for 1 hour

        return Response(data)
